GRANT ALL ON SCHEMA public TO myuser;
