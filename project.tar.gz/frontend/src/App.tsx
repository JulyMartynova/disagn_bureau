import React from 'react';
import './App.css';
import AllRoutes from "./components/allRoutes";

function App() {
    return (
        <AllRoutes/>
    );
}

export default App;
