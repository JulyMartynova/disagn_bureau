// export const BASE_URL = process.env.REACT_APP_API_URL;
export const BASE_URL = "http://localhost:8081/projects/";