import "../styles/footerstyles.css"

const Footer = () => {
    return (<div className="footer-container">
        <span>ООО «Дизайн бюро безопасных пространств»</span>
        <span>2024</span>

    </div>)
}

export default Footer;